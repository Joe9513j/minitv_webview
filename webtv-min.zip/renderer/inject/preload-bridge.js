// 文件路径: renderer/inject/preload-bridge.js
const { contextBridge, ipcRenderer } = require("electron");

ipcRenderer.on('execute-scripts-in-preload', (event, data) => {
    try {
        if (data.script1) {
            new Function(data.script1)();
        }

        if (data.script2) {
            new Function(data.script2)();
        }
    } catch (err) {
        ipcRenderer.send('video-error', err.message);
    }
});

contextBridge.exposeInMainWorld("electron", {
    ipcRenderer: {
        send: (channel, payload) => {
            if (["video-ready", "video-error"].includes(channel)) {
                ipcRenderer.send(channel, payload);
            } else {
                console.warn(`[Preload Bridge] Blocked message on untrusted channel: "${channel}"`);
            }
        }
    }
});
