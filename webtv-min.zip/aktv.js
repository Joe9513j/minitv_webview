const fs = require('fs');
const https = require('https');

const M3U_URL = 'https://aktv.space/live.m3u';

// 下载 M3U 文件内容
function fetchM3U(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

// 解析 M3U 内容为 JSON 格式
function parseM3UtoJSON(m3uContent) {
  const lines = m3uContent.split('\n').filter(line => line.trim() !== '');
  const result = [];
  let idCounter = 1;

  for (let i = 0; i < lines.length; i++) {
    if (lines[i].startsWith('#EXTINF')) {
      const nameMatch = lines[i].match(/,(.+)$/);
      const name = nameMatch ? nameMatch[1].trim() : `Channel ${idCounter}`;
      const url = lines[i + 1] || '';
      result.push({
        id: `aktv-${idCounter.toString().padStart(4, '0')}`,
        name,
        type: 'm3u8',
        group: 'AKTV',
        url,
        DEFAULT_MIN_QUALITY: null
      });
      idCounter++;
      i++; // Skip URL line
    }
  }

  return result;
}

// 合并两个 JSON 文件
function mergeJSONFiles(json1, json2) {
  return [...json1, ...json2];
}

// 主流程
async function main() {
  let aktvJson = [];
  let defaultJson = [];

  try {
    defaultJson = JSON.parse(fs.readFileSync('default.json', 'utf8'));
  } catch (err) {
    console.error('❌ Failed to load default.json:', err.message);
    return;
  }

  try {
    const m3uData = await fetchM3U(M3U_URL);
    aktvJson = parseM3UtoJSON(m3uData);
    fs.writeFileSync('aktv.json', JSON.stringify(aktvJson, null, 2), 'utf8');
    console.log('✅ aktv.json saved.');
  } catch (error) {
    console.warn('⚠️ Failed to fetch or parse AKTV M3U. Using default.json only.');
  }

  const finalJson = aktvJson.length > 0
    ? mergeJSONFiles(defaultJson, aktvJson)
    : defaultJson;

  fs.writeFileSync('channel.json', JSON.stringify(finalJson, null, 2), 'utf8');
  console.log('✅ channel.json saved.');
}

main();
